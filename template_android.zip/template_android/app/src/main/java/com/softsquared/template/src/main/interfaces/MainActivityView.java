package com.softsquared.template.src.main.interfaces;

public interface MainActivityView {

    void validateSuccess(String text);

    void validateFailure(String message);
}
